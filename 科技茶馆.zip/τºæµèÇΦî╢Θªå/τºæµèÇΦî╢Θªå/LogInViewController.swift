//
//  LogInViewController.swift
//  科技茶馆
//
//  Created by Apple on 2019-05-14.
//  Copyright © 2019 Scientific Teahouse. All rights reserved.
//

import UIKit
import Firebase
import SVProgressHUD
import FirebaseAuth
class LogInViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var emailTextfield: UITextField!
    
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBAction func logInPressed(_ sender: Any) {
        SVProgressHUD.show()
        
        Auth.auth().signIn(withEmail: emailTextfield.text!, password: passwordTextfield.text!) { (user, error) in
            
            if error != nil {
                print(error!)
            } else {
                print("Log in successful!")
                
                SVProgressHUD.dismiss()
                
                
                
            }
            
        }
        
    }
    
}
