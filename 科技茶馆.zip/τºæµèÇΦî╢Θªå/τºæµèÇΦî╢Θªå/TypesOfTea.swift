//
//  TypesOfTea.swift
//  科技茶馆
//
//  Created by Apple on 2019-05-07.
//  Copyright © 2019 Scientific Teahouse. All rights reserved.
//

import UIKit

class TypesOfTea: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
