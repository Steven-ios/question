//
//  Duck.swift
//  科技茶馆
//
//  Created by Apple on 2019-05-04.
//  Copyright © 2019 Scientific Teahouse. All rights reserved.
//

import Foundation

class Duck : Equatable{
    static func == (lhs: Duck, rhs: Duck) -> Bool {
        return lhs.x == rhs.x && lhs.y == rhs.y && lhs.size == rhs.size && lhs.xSpeed == rhs.xSpeed && lhs.ySpeed == rhs.ySpeed
    }
    
    
    var size = Int.random(in: 40 ..< 60)
    var xSpeed = Double.random(in: -10.0 ..< 10.0)
    var ySpeed = Double.random(in: -10.0 ..< 10.0)
    var x = 0.0
    var y = 0.0
    init(xin:Double, yin:Double){
        x = xin
        y = yin
    }
    
    func move(){
        x += xSpeed
        y += ySpeed
    }
}
