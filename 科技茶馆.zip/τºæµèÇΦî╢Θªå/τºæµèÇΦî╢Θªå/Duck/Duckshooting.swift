//
//  Duckshooting.swift
//  科技茶馆
//
//  Created by Apple on 2019-04-28.
//  Copyright © 2019 Scientific Teahouse. All rights reserved.
//

import UIKit

class Duckshooting: UIViewController {

    @IBOutlet weak var explosion: UIImageView!
    @IBOutlet weak var CrossHair: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        CrossHair.loadGif(name: "crosshairs")
        TIMER = Timer.scheduledTimer(timeInterval: 3.5, target: self, selector: #selector(Duckshooting.generate1), userInfo: nil, repeats: true)
        TIMER = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(Duckshooting.generate2), userInfo: nil, repeats: true)
    }
    
    public var screenWidth: CGFloat {
        return UIScreen.main.bounds.width
    }
    
    public var screenHeight: CGFloat {
        return UIScreen.main.bounds.height
    }
    //Generate Ducks
    var Ducks: Array<Duck> = Array()
    var TIMER = Timer()
    var TIMER2 = Timer()
    @objc func generate1(){
        let duck : Duck = Duck(xin: Double.random(in: 100.0 ..< Double(screenWidth)-100.0),yin: 0.0)
    Ducks.append(duck)
    }
    
    @objc func generate2(){
    for d in Ducks{
        if (d.x < 0 || Int(d.x) > Int(screenWidth)-d.size) {
            d.xSpeed *= -1;
        }
        if (d.y < 0 || Int(d.y) > Int(screenHeight)-d.size) {
            d.ySpeed *= -0.9; // bounce back and dampen the speed
        }
        d.move()
        display(duc: d)
    }
    }
    var duckks: Array<UIImageView> = Array()
    func display(duc:Duck){
        for image in duckks{
            image.removeFromSuperview()
        }
        duckks.removeAll()
        for d in Ducks{
        let imageView : UIImageView!
        imageView = UIImageView(frame: CGRect(x: CGFloat(d.x), y: CGFloat(d.y), width: CGFloat(d.size), height: CGFloat(d.size)))
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named:"ducks.png")
        self.view.addSubview(imageView)
        duckks.append(imageView)
        }
    }
    
 
    
 //Crosshair
    @IBAction func handlePan(recognizer:UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: self.view)
        if let view = recognizer.view {
            view.center = CGPoint(x:view.center.x + translation.x,
                                  y:view.center.y + translation.y)
        }
        recognizer.setTranslation(CGPoint.zero, in: self.view)
        if recognizer.state == UIGestureRecognizer.State.ended {
            self.explosion.isHidden = false
            explosion.frame = CGRect(x:CrossHair.frame.origin.x, y:CrossHair.frame.origin.y, width:42, height:30)
            explosion.loadGif(name: "explosion")
            Timer.scheduledTimer(withTimeInterval: 0.9, repeats: false) { (timer) in
                self.explosion.isHidden = true
            }
            for d in Ducks{
                let x = Double(CrossHair.frame.origin.x)-d.x
                let y = Double(CrossHair.frame.origin.y)-d.y
                if ((x*x + y*y) < 3600.0) {
                    Ducks.remove(at: Ducks.firstIndex(where: { $0 == d })!)
                    break
                }
            }
        }
        
    }
    
    //Background
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override var shouldAutorotate: Bool{
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return [UIInterfaceOrientationMask.landscapeLeft ,UIInterfaceOrientationMask.landscapeRight]
    }
    
    override var preferredInterfaceOrientationForPresentation:UIInterfaceOrientation{
        return .landscapeLeft
    }
}
